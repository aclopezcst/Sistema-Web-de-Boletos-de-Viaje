<?php

include('getconex.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $correo = $_POST["correo"];
    $contrasena = $_POST["contrasena"];
    $sql = "INSERT INTO tb_MetodoPaypal (IDCorreo, Contrasena) VALUES (?, ?)";
    $stmt = sqlsrv_prepare($conectar, $sql, array(&$correo, &$contrasena));

    if ($stmt) {
        if (sqlsrv_execute($stmt)) {
            // Obtener el ID de la última compra
            $sql = "SELECT TOP 1 IDCompra, IDViaje, Nombre, Correo, TipoPago FROM Compra ORDER BY IDCompra DESC";
            $stmt = sqlsrv_query($conectar, $sql);

            if ($stmt) {
                $row = sqlsrv_fetch_array($stmt);
                $idCompra = $row['IDCompra'];
                $idViaje = $row['IDViaje'];
                $nombre = $row['Nombre'];
                $correoCompra = $row['Correo'];
                $tipoPago = $row['TipoPago'];
                echo "Su compra se realizó con éxito.\n <br>";
                echo "Estos son los datos de tu cuenta:\n <br>";
                echo "ID de su compra: $idCompra\n <br>";
                echo "ID de su viaje: $idViaje\n <br>";
                echo "A nombre de: $nombre\n <br>";
                echo "Correo de comprador: $correoCompra\n <br>";
                echo "Tipo de pago: $tipoPago\n <br>";

                include('redirec.html');
            } else {
                echo "Error al obtener datos de la compra: ";
                //print_r(sqlsrv_errors());
            }
            sqlsrv_free_stmt($stmt);

        } else {
            //echo "Error al ejecutar la consulta de inserción: ";
            //print_r(sqlsrv_errors());
            include('sqlerror.php');
        }

    } else {
        //echo "Error al preparar la consulta de inserción: ";
        //print_r(sqlsrv_errors());
        include('sqlerror.php');
    }

    sqlsrv_close($conectar);
}

?>