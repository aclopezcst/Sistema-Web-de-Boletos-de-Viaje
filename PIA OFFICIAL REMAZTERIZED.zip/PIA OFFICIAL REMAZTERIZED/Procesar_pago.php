<?php
include("getconex.php");

$IDCompra = $_POST['IDCompra'];
$numeroTarjeta = $_POST['numeroTarjeta'];
$fechaExpiracion = $_POST['fechaExpiracion'];
$codigoSeguridad = $_POST['codigoSeguridad'];

$tsql = "EXEC InsertarPagoVisa ?, ?, ?, ?";  

$params = array($IDCompra, $numeroTarjeta, $fechaExpiracion, $codigoSeguridad);

$conn = sqlsrv_connect($serverName, $connectionInfo);

if ($conn) {
    $stmt = sqlsrv_query($conn, $tsql, $params);

    if ($stmt === false) {
        echo "Error al ejecutar la consulta: " . print_r(sqlsrv_errors(), true);
    } else {
        echo "Pago realizado correctamente.";
        // Aquí podrías redirigir a una página de éxito o mostrar un mensaje adecuado
    }

    sqlsrv_free_stmt($stmt);
    sqlsrv_close($conn);
} else {
    echo "Conexión fallida.";
}
?>