Use GrupoSenda

CREATE TABLE Viajes(
	IDViaje INT PRIMARY KEY NOT NULL,
	Origen nvarchar(20) NOT NULL,
	Destino nvarchar(20) NOT NULL,
	FechIda nvarchar(10) NOT NULL,
    FechReg nvarchar(10) NOT NULL,
	Linea nvarchar(15) NOT NULL,
	HoraSar nvarchar(10) NOT NULL,
	Precio_MXN INT NOT NULL
	);

ALTER TABLE Viajes
ADD Duracion nvarchar(10) NOT NULL;

ALTER TABLE Viajes
ADD HoraSar2 nvarchar(10) NOT NULL;

SELECT * FROM Viajes

MONTERREY - CDMX

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122199, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '---', 'Senda', '09:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122198, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '---', 'Senda', '17:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122197, 'Monterrey, N.L.', 'CDMX', '31/12/2023', '---', 'Senda', '09:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122196, 'Monterrey, N.L.', 'CDMX', '01/01/2024', '---', 'Senda', '09:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122195, 'Monterrey, N.L.', 'CDMX', '02/01/2024', '---', 'Senda', '09:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122194, 'Monterrey, N.L.', 'CDMX', '02/01/2024', '---', 'Senda', '17:00 hrs', 800.00, '9 hrs', '---')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122193, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '31/12/2023', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122192, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '31/12/2023', 'Senda', '17:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122191, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '01/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122190, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '01/01/2024', 'Senda', '17:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122189, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '02/01/2024', 'Senda', '09:00 hrs',1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122188, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '02/01/2024', 'Senda', '09:00 hrs',1400.00, '9 hrs', '17:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122187, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '02/01/2024', 'Senda', '17:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122186, 'Monterrey, N.L.', 'CDMX', '30/12/2023', '02/01/2024', 'Senda', '17:00 hrs', 1400.00, '9 hrs', '17:00 hrs')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122185, 'Monterrey, N.L.', 'CDMX', '31/12/2023', '01/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122184, 'Monterrey, N.L.', 'CDMX', '31/12/2023', '02/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122183, 'Monterrey, N.L.', 'CDMX', '31/12/2023', '02/01/2024', 'Senda', '09:00 hrs',1400.00, '9 hrs', '17:00 hrs')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122182, 'Monterrey, N.L.', 'CDMX', '01/01/2024', '02/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(122181, 'Monterrey, N.L.', 'CDMX', '01/01/2024', '02/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '17:00 hrs')



MONTERREY - AUSTIN

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132180, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '---', 'Turimex', '09:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132179, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '---', 'Turimex', '17:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132178, 'Monterrey, N.L.', 'Austin, Tx.', '31/12/2023', '---', 'Turimex', '09:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132177, 'Monterrey, N.L.', 'Austin, Tx.', '01/01/2024', '---', 'Turimex', '09:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132176, 'Monterrey, N.L.', 'Austin, Tx.', '02/01/2024', '---', 'Turimex', '09:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132175, 'Monterrey, N.L.', 'Austin, Tx.', '02/01/2024', '---', 'Turimex', '17:00 hrs', 1200.00, '12 hrs', '---')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132174, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '31/12/2023', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132173, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '31/12/2023', 'Turimex', '17:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132172, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '01/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132171, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '01/01/2024', 'Turimex', '17:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132170, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132169, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '17:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132168, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '02/01/2024', 'Turimex', '17:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132167, 'Monterrey, N.L.', 'Austin, Tx.', '30/12/2023', '02/01/2024', 'Turimex', '17:00 hrs', 2000.00, '12 hrs', '17:00 hrs')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132166, 'Monterrey, N.L.', 'Austin, Tx.', '31/12/2023', '01/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132165, 'Monterrey, N.L.', 'Austin, Tx.', '31/12/2023', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132164, 'Monterrey, N.L.', 'Austin, Tx.', '31/12/2023', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '17:00 hrs')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132163, 'Monterrey, N.L.', 'Austin, Tx.', '01/01/2024', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(132162, 'Monterrey, N.L.', 'Austin, Tx.', '01/01/2024', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '17:00 hrs')



CDMX - MONTERREY

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212161, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '---', 'Senda', '09:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212160, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '---', 'Senda', '17:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212159, 'CDMX', 'Monterrey, N.L.', '31/12/2023', '---', 'Senda', '09:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212158, 'CDMX', 'Monterrey, N.L.', '01/01/2024', '---', 'Senda', '09:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212157, 'CDMX', 'Monterrey, N.L.', '02/01/2024', '---', 'Senda', '09:00 hrs', 800.00, '9 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212156, 'CDMX', 'Monterrey, N.L.', '02/01/2024', '---', 'Senda', '17:00 hrs', 800.00, '9 hrs', '---')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212155, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '31/12/2023', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212154, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '31/12/2023', 'Senda', '17:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212153, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '01/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212152, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '01/01/2024', 'Senda', '17:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212151, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '02/01/2024', 'Senda', '09:00 hrs',1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212150, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '02/01/2024', 'Senda', '09:00 hrs',1400.00, '9 hrs', '17:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212149, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '02/01/2024', 'Senda', '17:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212148, 'CDMX', 'Monterrey, N.L.', '30/12/2023', '02/01/2024', 'Senda', '17:00 hrs', 1400.00, '9 hrs', '17:00 hrs')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212147, 'CDMX', 'Monterrey, N.L.', '31/12/2023', '01/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212146, 'CDMX', 'Monterrey, N.L.', '31/12/2023', '02/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212145, 'CDMX', 'Monterrey, N.L.', '31/12/2023', '02/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '17:00 hrs')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212144, 'CDMX', 'Monterrey, N.L.', '01/01/2024', '02/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(212143, 'CDMX', 'Monterrey, N.L.', '01/01/2024', '02/01/2024', 'Senda', '09:00 hrs', 1400.00, '9 hrs', '17:00 hrs')




AUSTIN - MONTERREY

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312142, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '---', 'Turimex', '09:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312141, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '---', 'Turimex', '17:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312140, 'Austin, Tx.', 'Monterrey, N.L.', '31/12/2023', '---', 'Turimex', '09:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312139, 'Austin, Tx.', 'Monterrey, N.L.', '01/01/2024', '---', 'Turimex', '09:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312138, 'Austin, Tx.', 'Monterrey, N.L.', '02/01/2024', '---', 'Turimex', '09:00 hrs', 1200.00, '12 hrs', '---')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312137, 'Austin, Tx.', 'Monterrey, N.L.', '02/01/2024', '---', 'Turimex', '17:00 hrs', 1200.00, '12 hrs', '---')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312136, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '31/12/2023', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312135, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '31/12/2023', 'Turimex', '17:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312134, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '01/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312133, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '01/01/2024', 'Turimex', '17:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312132, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312131, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '17:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312130, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '02/01/2024', 'Turimex', '17:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312129, 'Austin, Tx.', 'Monterrey, N.L.', '30/12/2023', '02/01/2024', 'Turimex', '17:00 hrs', 2000.00, '12 hrs', '17:00 hrs')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312128, 'Austin, Tx.', 'Monterrey, N.L.', '31/12/2023', '01/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312127, 'Austin, Tx.', 'Monterrey, N.L.', '31/12/2023', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312126, 'Austin, Tx.', 'Monterrey, N.L.', '31/12/2023', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '17:00 hrs')



INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312125, 'Austin, Tx.', 'Monterrey, N.L.', '01/01/2024', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '09:00 hrs')

INSERT INTO Viajes (IDViaje, Origen, Destino, FechIda, FechReg, Linea, HoraSar, Precio_MXN, Duracion, HoraSar2)
VALUES(312124, 'Austin, Tx.', 'Monterrey, N.L.', '01/01/2024', '02/01/2024', 'Turimex', '09:00 hrs', 2000.00, '12 hrs', '17:00 hrs')