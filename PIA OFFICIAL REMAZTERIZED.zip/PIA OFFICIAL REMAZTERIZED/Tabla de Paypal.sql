CREATE TABLE tb_MetodoPaypal (
    IDPago INT PRIMARY KEY IDENTITY (0001,0001),
    IDCorreo NVARCHAR(40) NOT NULL CHECK (CHARINDEX('@', IDCorreo) > 0),
    Contrasena NVARCHAR(30) NOT NULL
);

Esta tabla necesita cambiar la llave primaria, donde esa llave primaria
de preferencia sea un IDPago y el IDcorreo y contrasena sean datos normales



