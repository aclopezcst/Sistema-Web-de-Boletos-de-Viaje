USE GrupoSenda
 
 
CREATE TABLE Compra(
    IDCompra INT PRIMARY KEY IDENTITY (0001,0001),
    IDViaje INT NOT NULL,
    Nombre NVARCHAR(50) NOT NULL,
    Correo NVARCHAR(50) NOT NULL,
    TipoPago NVARCHAR(10) NOT NULL, 
);
 
SELECT * FROM Compra
 
GO
CREATE PROCEDURE ComprobarCompra
@IDVia INT, @Nom NVARCHAR(50), @Cor NVARCHAR(50), @Control NVARCHAR(10)
AS
SELECT * FROM Compra WHERE IDViaje=@IDVia AND Nombre=@Nom AND Correo=@Cor AND @Control ='grUp0s3nd4'
GO