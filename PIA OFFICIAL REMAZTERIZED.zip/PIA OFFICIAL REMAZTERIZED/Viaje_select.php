<?php

include('getconex.php');

$IDViaje=$_POST['IDViaje'];
$NomUser=$_POST['Nombre'];
$CorreoUsu=$_POST['Correo'];
$TipPag=$_POST['TipoPago'];

$ins_sql = "INSERT INTO Compra
VALUES('$IDViaje','$NomUser','$CorreoUsu','$TipPag')";

$stmt= sqlsrv_query($conectar,$ins_sql);

if ($stmt) {
    echo '<br><b> Datos ingresados correctamente. </b>';

    if ($TipPag == 'VISA') {
        include('form_visa.html');
    
    }
    else {
     include('PAYPAL.html');
    
    }

} else {
    include('sqlerror.php');
    
}

?>
