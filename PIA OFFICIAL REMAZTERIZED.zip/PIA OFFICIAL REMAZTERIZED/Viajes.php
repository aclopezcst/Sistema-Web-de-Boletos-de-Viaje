<?php
 
include('getconex.php');
 
$varOrg = $_POST['Origen'];
$varDest = $_POST['Destino'];
$varFecI = $_POST['FechIda'];
$varFecR = $_POST['FechReg'];

//echo $varOrg;
//echo $varDest;
//echo $varFecI;
//echo $varFecR;

$tsql = "SELECT * FROM Viajes WHERE Origen = '$varOrg' AND Destino = '$varDest' AND FechIda = '$varFecI' AND FechReg = '$varFecR'";  
$stmt = sqlsrv_query($conectar, $tsql);

if ($stmt === false){
        include('sqlerror.php');
    } 

if ($varFecR == '---'){
    echo "<label for='name'>Viajes disponibles</label>";  
      
    echo "<table>";
    echo "<tr><th>ID</th><th>Origen</th><th>Destino</th><th>Fecha de ida</th><th>Hora de salida</th><th>Linea</th><th>Precio (MXN)</th><th>Duracion</th></tr>";
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . $row['IDViaje'] . "</td>";
            echo "<td>" . $row['Origen'] . "</td>";
            echo "<td>" . $row['Destino'] . "</td>";
            echo "<td>" . $row['FechIda'] . "</td>";
            echo "<td>" . $row['HoraSar'] . "</td>";
            echo "<td>" . $row['Linea'] . "</td>";
            echo "<td>" . $row['Precio_MXN'] . "</td>";
            echo "<td>" . $row['Duracion'] . "</td>";
            echo "</tr>";
            }
    echo "</table>";
    
    include('Compra.html');

    sqlsrv_close($conectar);
}

else{
    echo "<th><label for='name'>Viajes disponibles</label></th>";
    
    echo "<table>";
    echo "<tr><th>ID</th><th>Origen</th><th>Destino</th><th>Fecha de ida</th><th>Hora de salida</th><th>Fecha de regreso</th><th>Hora de salida</th><th>Linea</th><th>Precio (MXN)</th><th>Duracion</th></tr>";
        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . $row['IDViaje'] . "</td>";
            echo "<td>" . $row['Origen'] . "</td>";
            echo "<td>" . $row['Destino'] . "</td>";
            echo "<td>" . $row['FechIda'] . "</td>";
            echo "<td>" . $row['HoraSar'] . "</td>";
            echo "<td>" . $row['FechReg'] . "</td>";
            echo "<td>" . $row['HoraSar2'] . "</td>";
            echo "<td>" . $row['Linea'] . "</td>";
            echo "<td>" . $row['Precio_MXN'] . "</td>";
            echo "<td>" . $row['Duracion'] . "</td>";
            echo "</tr>";
            }
        echo "</table>";
        
        include('Compra.html');

        sqlsrv_close($conectar);
}

?>
