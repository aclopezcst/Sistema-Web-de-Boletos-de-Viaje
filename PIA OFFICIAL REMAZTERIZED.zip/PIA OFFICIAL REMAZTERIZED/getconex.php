<?php

$serverName = 'LAPTOP-GSE1RQS5';   
$connectionInfo = array( 'Database'=>'GrupoSenda', 'UID'=>'LSBDUSER', 'PWD'=>'C0ntr4s3n4*#'); 
$conectar = sqlsrv_connect($serverName, $connectionInfo);  

if ($conectar) {

    echo '<br>';
}

else {

    echo 'Hubo un error al conectarse a la base de datos. <br>';
}

?>

