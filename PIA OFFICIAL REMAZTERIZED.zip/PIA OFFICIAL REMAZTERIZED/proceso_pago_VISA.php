<?php
include('getconex.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numTarjeta = $_POST["NumTarjeta"];
    $codigoSeguridad = $_POST["CodigoSeguridad"];
    session_start();
    $sqlGetID = "SELECT TOP 1 IDCompra FROM Compra ORDER BY NEWID()"; 
    $stmtGetID = sqlsrv_query($conectar, $sqlGetID);
    if ($stmtGetID) {
        $rowID = sqlsrv_fetch_array($stmtGetID, SQLSRV_FETCH_ASSOC);
        $idCompra = ($rowID) ? $rowID['IDCompra'] : time() . mt_rand(100, 999); 
        $_SESSION['IDCompra'] = $idCompra;
        $sqlInsert = "INSERT INTO tb_InfoVisa (IDCompra, NumTarjeta, CodigoSeguridad) VALUES (?, ?, ?)";
        $paramsInsert = array($idCompra, $numTarjeta, $codigoSeguridad);
        $stmtInsert = sqlsrv_query($conectar, $sqlInsert, $paramsInsert);
        if ($stmtInsert) {
            echo "PAGO EXITOSO!";
            include('redirec.html');

        } else {
            echo "Error al agregar datos a la tabla: ";
            include('sqlerror.php'); 
            //print_r(sqlsrv_errors(), true)
        }

        sqlsrv_free_stmt($stmtGetID);
    } else {
        echo "Error al obtener IDCompra: ";
        include ('sqlerror.php');
    }
    sqlsrv_close($conectar);
} else {
    echo "Método de solicitud no válido.";
}
?>

