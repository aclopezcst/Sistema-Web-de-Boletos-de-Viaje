<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}    

$date = date('[Y/m/d H:i:s] ');
$dirip = " [" . $ip . "] ";

$sqlerror = print_r( sqlsrv_errors(), true);

error_log($date . $dirip . " Error de SQL Server: " . $sqlerror,3,'C:\xampp\apache\logs\sqlsrv_error.log');

        echo '<script type="text/javascript">';
        echo ' alert("Pagina no disponible")';
        echo '</script>';
        echo "<script>setTimeout(\"location.href = 'javascript:history.go(-1)';\",1);</script>";

    die();
?>




