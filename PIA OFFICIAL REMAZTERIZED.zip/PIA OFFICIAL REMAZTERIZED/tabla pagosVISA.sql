CREATE TABLE tb_InfoVisa (
    IDPago INT PRIMARY KEY IDENTITY(1, 1),
    IDCompra int,
    NumTarjeta VARCHAR(16) NOT NULL,
    CodigoSeguridad VARCHAR(4) NOT NULL,
);

ALTER TABLE tb_InfoVisa
ADD FOREIGN KEY (IDCompra) REFERENCES Compra(IDCompra)

SELECT * FROM tb_InfoVisa

CREATE PROCEDURE verificarcompraVisa
@NumTar VARCHAR(16), @CodSeg VARCHAR(4), @Control NVARCHAR(10)
AS
SELECT * FROM tb_InfoVisa WHERE NumTarjeta = @NumTar AND CodigoSeguridad = @CodSeg AND @Control = 'grUp0s3nd44'
GO